bash "say hello" do
  cwd "~/"
  code "say hello chef"
end
